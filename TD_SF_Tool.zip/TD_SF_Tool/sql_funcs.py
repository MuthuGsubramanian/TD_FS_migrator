import re
from macro_coversion_config import *
import logging


def shift_date_time(merge_script):
    merge_block = []
    merge = merge_script.split('\n')
    for i, ite in enumerate(merge):
        if re.findall('shift_info.shiftstartdatetime', ite):
            col_name = ite.split('+')[0].strip()
            field = re.search(r'cast([^/]+)', ''.join(ite.split('+')[1])).group(1).replace('(', '').strip()
            update_col = conf_map['date_add'].format(field, col_name) + ' as ' + field + '_ts ,'
            logging.info(update_col)
            merge_block.append(update_col + '\n')

        else:
            merge_block.append(ite + '\n')

    return merge_block