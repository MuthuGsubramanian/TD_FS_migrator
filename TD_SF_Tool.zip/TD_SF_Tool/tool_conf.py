import datetime

log_file = str(datetime.datetime.now().strftime("logs_%Y-%m-%d %H~%M~%S.txt"))