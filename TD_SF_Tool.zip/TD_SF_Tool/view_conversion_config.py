conf_map = {
    'create view': '''CREATE OR REPLACE VIEW {0}.{1}''',
    'mod': '//',
    'Datediff':'//',
    'Timeadd':'//'
}